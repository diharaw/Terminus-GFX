#pragma once

#if defined(__APPLE__)

#include <objc/objc-runtime.h>

namespace MTL
{
    class DescriptorHeap
    {
        
    };
}

#endif

