#pragma once

#define TE_RENDER_DEVICE_GL

#if defined(TE_RENDER_DEVICE_GL)
#include <gl/gl_render_device.h>
#endif
